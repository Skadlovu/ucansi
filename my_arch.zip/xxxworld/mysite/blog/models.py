from django.db import models
from django.utils.html import strip_tags
from django.utils.safestring import mark_safe
from django.utils.timesince import timesince


class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField(blank=True, null=True)
    img=models.ImageField(upload_to='blog-images',null=True)
    pub_date = models.DateTimeField(auto_now_add=True)
    views = models.IntegerField(blank=True, default=0)
    likes = models.IntegerField(blank=True, default=0)

    def __str__(self):
        return self.title

    def get_content_without_tags(self):
        return strip_tags(self.content)

    def get_reading_time(self):
        words_per_minute = 200  # Adjust as needed for your audience
        word_count = len(self.get_content_without_tags().split())
        reading_time_minutes = word_count / words_per_minute
        return round(reading_time_minutes)

    def time_since_post(self):
        time_since = timesince(self.pub_date)
        days_since = time_since.split(", ")[0]  # Get only the number of days
        return f"{days_since}"
