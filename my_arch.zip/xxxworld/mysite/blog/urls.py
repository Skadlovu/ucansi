from django.urls import path
from .views import post_list, post_detail, LikePostView

app_name='blog'

urlpatterns = [
    path('blog/post_list', post_list, name='post_list'),
    path('blog/post/<int:pk>/', post_detail, name='post_detail'),
    path('blog/post/<int:pk>/', LikePostView.as_view(), name='like_post'),
]
