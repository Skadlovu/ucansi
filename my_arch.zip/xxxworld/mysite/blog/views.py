from random import sample
from django.shortcuts import render,redirect,get_object_or_404
from .models import Post
from watchanalytics.models import BlogViews
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from videos.models import VidStream,Category
from photos.models import Photo
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt, csrf_protect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from taggit.models import Tag

def post_list(request):
    posts = Post.objects.all().order_by('-pub_date')
    paginator = Paginator(posts, 16)  # Show 12 articles per page

    page = request.GET.get('page')
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        posts = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        posts = paginator.page(paginator.num_pages)

    return render(request, 'blog/post_list.html', {'posts': posts})


def post_detail(request, pk):
    post = Post.objects.get(pk=pk)
    all_articles = Post.objects.exclude(pk=pk)
    other_articles = sample(list(all_articles), min(7, len(all_articles)))
    all_videos=VidStream.objects.all()
    videos = sample(list(all_videos), min(7, len(all_videos)))
    all_photos=Photo.objects.all()
    photos=sample(list(all_photos), min(7, len(all_photos)))
    all_categories=Category.objects.all()
    categories=sample(list(all_categories), min(7, len(all_categories)))
    all_tags=Tag.objects.all()
    tags=sample(list(all_tags), min(7, len(all_tags)))


    if not request.session.session_key:
        request.session.save()
    session_key= request.session.session_key
    is_views=BlogViews.objects.filter(videoId=pk, sesID=session_key)
    if is_views.count()== 0 and str(session_key) !="None":
        views=BlogViews()
        views.sesID=session_key
        views.videoId=post
        views.save()
        post.views += 1
        post.save()
    prev_article = Post.objects.filter(pub_date__lt=post.pub_date).order_by('-pub_date').first()
    next_article = Post.objects.filter(pub_date__gt=post.pub_date).order_by('pub_date').first()
    return render(request, 'blog/post_detail.html', {'tags':tags,'categories':categories,'photos':photos, 'post': post,'other_articles':other_articles,'videos':videos, 'prev_article': prev_article, 'next_article': next_article})

@method_decorator(login_required, name='dispatch')
class LikePostView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def post(self, request, pk):
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            post = get_object_or_404(Post, pk=pk)

            if request.user in post.likes.all():
                # User has already liked the post, unlike it
                post.likes.remove(request.user)
                liked = False
            else:
                # User hasn't liked the post, like it
                post.likes.add(request.user)
                liked = True

            response_data = {'liked': liked, 'like_count': post.likes.count()}
            return JsonResponse(response_data)

        return redirect('blog:post_detail', pk=pk)
