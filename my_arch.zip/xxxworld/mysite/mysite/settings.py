from google.oauth2 import service_account
from pathlib import Path
import os
from decouple import config
from celery import Celery

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent



SECRET_KEY =config('SECRET_KEY')




CELERY_BROKER_URL = 'redis://localhost:6379/0'
CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mysite.settings')

app = Celery('mysite')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()



EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'

EMAIL_HOST = 'smtp.xxxworld.site'

EMAIL_PORT = 587

EMAIL_USE_TLS = True

EMAIL_HOST_USER = config('EMAIL_HOST_USER')

EMAIL_HOST_PASSWORD =config('EMAIL_HOST_PASSWORD')




DEBUG = False
#

ALLOWED_HOSTS = ['xxxworld.online','www.xxxworld.online', 'www.xxxworld.site', 'xxxworld.site']


LOGIN_URL= 'login'


LOGIN_REDIRECT_URL= '/'

LOGOUT_REDIRECT_URL= '/'




CRISPY_ALLOWED_TEMPLATE_PACKS = "bootstrap4"



CRISPY_TEMPLATE_PACK = 'bootstrap4'



DEFAULT_AUTO_FIELD= 'django.db.models.BigAutoField'





# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'photos',
    'videos',
    'profiles',
    'crispy_forms',
    'crispy_bootstrap4',
    'watchanalytics',
    'payfast',
    'contact',
    #'stream',
    #'django_q',
    'donations',
    'taggit',
    "corsheaders",
    "blog",
    "celery"
]

Q_CLUSTER = {
    'name': 'xxxworld',
    'workers': 4,
    'recycle': 500,
    'timeout': 60,  # Set the timeout to a value suitable for your task
    'retry': 600,   # Set the retry to a value larger than the timeout
    'queue_limit': 50,
    'bulk': 10,
    'orm': 'default',
    'db_failures': 1000,
    'redis': {
        'host': 'localhost',
        'port': 6379,
        'db': 0,
        'password': 'your_password',
        'socket_timeout': 3,
        'socket_connect_timeout': 3,
        'max_connections': 20,
        'retry_on_timeout': True,
        'skip_full': True
    }
}

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    "corsheaders.middleware.CorsMiddleware",
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]


TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [ os.path.join(BASE_DIR ,'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]


CORS_ALLOWED_ORIGINS = [
    "https://storage.googleapis.com"
]




ROOT_URLCONF = "mysite.urls"



WSGI_APPLICATION = "mysite.wsgi.application"

ASGI_APPLICATION = 'stream.routing.application'


# Database

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# Password validation
# https://docs.djangoproject.com/en/4.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization

LANGUAGE_CODE = 'en-us'

TIME_ZONE = config('TIME_ZONE')

USE_I18N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
#STATIC_URL = 'http:www.xxxworld.site/static/'
"""
STATICFILES_DIRS= STATICFILES_DIRS = [
    BASE_DIR / 'static',
]

STATIC_ROOT = '/home/ubuntu/mabuda01/xxxworld/staticfiles'
"""
#MEDIA_URL = '/media/'


#MEDIA_ROOT = os.path.join(BASE_DIR, 'media')




# G storage credentials
GS_CREDENTIALS = service_account.Credentials.from_service_account_file(
    os.path.join(BASE_DIR, 'orbital-anchor-414318-b3af899ba150.json')
)

# Google Cloud Storage bucket name
GS_BUCKET_NAME = 'xxxwfiles'



MEDIA_FOLDER='/media/'

STATIC_FOLDER='/static/'

# Google Cloud Storage base URL for media files
MEDIA_URL= f'https://storage.googleapis.com/{GS_BUCKET_NAME}/media/'

#Mediafiles storage backend
DEFAULT_FILE_STORAGE = 'mysite.gscUtils.Media'



# Google Cloud Storage base URL for static files
STATIC_URL=f'https://storage.googleapis.com/{GS_BUCKET_NAME}/static/'

# Staticfiles storage backend
STATICFILES_STORAGE = 'mysite.gscUtils.Static'




GS_OBJECT_PARAMETERS = {
    'CacheControl': 'max-age=86400',
}





#payfast
def payfast_url():
    from django.contrib.sites.models import Site
    site=Site.objects.get_current()
    return 'http: //{}'.format(site.domain)



PAYFAST_MERCHANT_ID=config('merchant_id')
PAYFAST_MERCHANT_KEY=config('merchant_key')
PAYFAST_URL_BASE= payfast_url


#Taggit
TAGGIT_CASE_INSENSITIVE=True
















