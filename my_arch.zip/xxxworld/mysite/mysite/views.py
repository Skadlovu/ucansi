from django.core.mail import send_mail
from django.conf import settings
from contact.models import Contact
from contact.forms import ContactForm
from django.shortcuts import render


def privacy(request):
    return render(request, "privacy_policy.html")

def terms(request):
    return render(request, "terms.html")

def copyright(request):
    return render(request, "copyright.html")

def assist(request):
    if request.method == 'POST':
        con_form = ContactForm(request.POST)
        if con_form.is_valid():
            # Save the form data to the Contact model
            contact = con_form.save(commit=False)
            contact.save()

            subject = con_form.cleaned_data['subject']
            message = con_form.cleaned_data['message']
            sender_email = con_form.cleaned_data['email']

            # Send an email
            send_mail(
                [subject],
                [message],
                [sender_email],
                settings.EMAIL_HOST_USER,
                ['admin@xxxworld.site'],
                fail_silently=False,
            )

            return render(request, 'success.html')
    else:
        con_form = ContactForm()
    context = {'con_form': con_form}
    return render(request, 'assist.html', context)

def success(request):
    return render(request,'success.html')
