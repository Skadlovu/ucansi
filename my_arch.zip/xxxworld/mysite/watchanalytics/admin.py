from django.contrib import admin
from. models import Analytics, PictureViews,BlogViews


class PictureViewsAdmin(admin.ModelAdmin):
    list_display = ('sesID', 'videoId')
    list_filter = ('videoId',)


class BlogViewsAdmin(admin.ModelAdmin):
    list_display = ('sesID', 'videoId')
    list_filter = ('videoId',)

admin.site.register(BlogViews)

admin.site.register(PictureViews)



class AnalyticsAdmin(admin.ModelAdmin):
    list_display = ('sesID', 'videoId', 'get_video_title', 'total_analytics')
    list_filter = ('videoId',)

    def get_video_title(self, obj):
        return obj.videoId.title
    get_video_title.short_description = 'Video Title'

    def total_analytics(self, obj):
        return Analytics.objects.filter(videoId=obj.videoId).count()
    total_analytics.short_description = 'Total Analytics'

admin.site.register(Analytics, AnalyticsAdmin)