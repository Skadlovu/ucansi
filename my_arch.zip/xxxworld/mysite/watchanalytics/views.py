from django.shortcuts import render
from django.utils.timezone import make_aware
from datetime import datetime, timedelta
from .models import Analytics, PictureViews, BlogViews

def analytics_hourly_view(request):
    date_str = request.GET.get('date')
    if date_str:
        date = datetime.strptime(date_str, '%Y-%m-%d')
        date = make_aware(date)
    else:
        date = datetime.now()
        date = make_aware(date.replace(hour=0, minute=0, second=0, microsecond=0))

    start_date = date
    end_date = start_date + timedelta(days=1)

    analytics_data = []
    picture_views_data = []
    blog_views_data = []

    # Fetch data for Analytics
    for hour in range(24):
        start_hour = start_date + timedelta(hours=hour)
        end_hour = start_hour + timedelta(hours=1)

        analytics_count = Analytics.objects.filter(timestamp__gte=start_hour, timestamp__lt=end_hour).count()
        cumulative_analytics_count = Analytics.objects.filter(timestamp__gte=start_date, timestamp__lt=end_hour).count()

        analytics_data.append({
            'hour': f'{hour:02d}:00 - {hour + 1:02d}:00',
            'count': analytics_count,
            'cumulative': cumulative_analytics_count,
        })

    # Fetch data for PictureViews
    for hour in range(24):
        start_hour = start_date + timedelta(hours=hour)
        end_hour = start_hour + timedelta(hours=1)

        picture_views_count = PictureViews.objects.filter(timestamp__gte=start_hour, timestamp__lt=end_hour).count()
        cumulative_picture_views_count = PictureViews.objects.filter(timestamp__gte=start_date, timestamp__lt=end_hour).count()

        picture_views_data.append({
            'hour': f'{hour:02d}:00 - {hour + 1:02d}:00',
            'count': picture_views_count,
            'cumulative': cumulative_picture_views_count,
        })

    # Fetch data for BlogViews
    for hour in range(24):
        start_hour = start_date + timedelta(hours=hour)
        end_hour = start_hour + timedelta(hours=1)

        blog_views_count = BlogViews.objects.filter(timestamp__gte=start_hour, timestamp__lt=end_hour).count()
        cumulative_blog_views_count = BlogViews.objects.filter(timestamp__gte=start_date, timestamp__lt=end_hour).count()

        blog_views_data.append({
            'hour': f'{hour:02d}:00 - {hour + 1:02d}:00',
            'count': blog_views_count,
            'cumulative': cumulative_blog_views_count,
        })

    context = {
        'analytics_data': analytics_data,
        'picture_views_data': picture_views_data,
        'blog_views_data': blog_views_data,
        'selected_date': date_str if date_str else date.strftime('%Y-%m-%d'),
    }

    return render(request, 'analytics_hourly.html', context)
