from django.db import models
from videos.models import VidStream
from photos.models import Photo
from blog.models import Post



class Analytics(models.Model):
    sesID = models.CharField(verbose_name='session ID', max_length=150, db_index=True)
    videoId = models.ForeignKey(VidStream, blank=True, null=True, default=None, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True, blank=True, null=True)  # Add this line
    created_at=models.DateTimeField(auto_now_add=True, blank=True, null=True)

    def __str__(self):
        return '{} - {}'.format(self.sesID, self.videoId)





class PictureViews(models.Model):
	sesID= models.CharField(verbose_name='session ID', max_length=150, db_index=True)
	videoId = models.ForeignKey(Photo, blank=True, null=True, default=None, on_delete=models.CASCADE)
	timestamp = models.DateTimeField(auto_now_add=True, blank=True, null=True)  # Add this line
	created_at=models.DateTimeField(auto_now_add=True, blank=True, null=True)


	def __str__(self):
		return '{} - {}'.format(self.sesID, self.videoId)

class BlogViews(models.Model):
	sesID= models.CharField(verbose_name='session ID', max_length=150, db_index=True)
	videoId = models.ForeignKey(Post, blank=True, null=True, default=None, on_delete=models.CASCADE)
	timestamp = models.DateTimeField( blank=True, null=True)  # Add this line
	created_at=models.DateTimeField(auto_now_add=True, blank=True, null=True)


	def __str__(self):
		return '{} - {}'.format(self.sesID, self.videoId)



