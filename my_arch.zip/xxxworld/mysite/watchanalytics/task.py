from celery import shared_task
from django.core.mail import EmailMessage
from .views import analytics_hourly_view
from django.template.loader import render_to_string
from django.utils import timezone

@shared_task
def send_daily_report():
    # Generate the report
    report_date = timezone.now().date()
    report_data = analytics_hourly_view(None, report_date)

    # Render the report template
    report_html = render_to_string('daily_report.html', {'report_data': report_data})

    # Send the report via email
    email = EmailMessage(
        'Daily Report',
        'Please find the daily report attached.',
        'admin@xxxworld.site',
        ['skandlovu@gmail.com'],
    )
    email.attach('report.html', report_html, 'text/html')
    email.send()
