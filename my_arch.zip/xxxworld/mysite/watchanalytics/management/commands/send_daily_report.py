# In your app's management/commands folder, create a new Python file, e.g., send_daily_report.py

from django.core.management.base import BaseCommand
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.utils import timezone
from watchanalytics.views import analytics_hourly_view

class Command(BaseCommand):
    help = 'Send daily report for analytics_hourly_view'

    def handle(self, *args, **kwargs):
        # Call the analytics_hourly_view to get the data for the report
        request = None  # Since we're not using a request object in the view
        hourly_data = analytics_hourly_view(request).context_data['hourly_data']

        # Render the template with the hourly_data
        context = {'hourly_data': hourly_data}
        message = render_to_string('daily_report_email.html', context)

        # Send the email
        subject = 'Daily Report for Analytics'
        from_email = 'admin@xxxworld.site'
        to_emails = ['skandlovu@gmail.com'] # Add your recipients' email addresses
        email = EmailMessage(subject, message, from_email, to_emails)
        email.send()
