# get_video_info.py
from ffprobe import FFProbe

def get_video_info(file_path):
    try:
        probe = FFProbe(file_path)
        video_info = next(s for s in probe.streams if s.is_video())
        duration = video_info.duration
        size = video_info.size
        return duration, size
    except Exception as e:
        print(f"Error getting video information: {e}")
        return None, None
