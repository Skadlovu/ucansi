from django import template
from django.utils.timesince import timesince
from django.utils.timezone import now
from django.utils.dateparse import parse_datetime

register = template.Library()

@register.filter(name='custom_timesince')
def custom_timesince(value):
    if not value:
        return ''

    # Convert value to a valid date/time object
    value = parse_datetime(value)

    if value is None:
        return ''  # Return empty string if value is not a valid date/time

    delta = now() - value
    if delta.days > 7:
        return f"{delta.days // 7} weeks ago"
    elif delta.days > 0:
        return f"{delta.days} days ago"
    elif delta.seconds >= 3600:
        return f"{delta.seconds // 3600} hours ago"
    elif delta.seconds >= 60:
        return f"{delta.seconds // 60} minutes ago"
    else:
        return "just now"
