from django import template

register = template.Library()

@register.filter
def cumulative_sum(values, up_to):
    total = 0
    for i, value in enumerate(values):
        if i >= up_to:
            break
        total += value
    return total
